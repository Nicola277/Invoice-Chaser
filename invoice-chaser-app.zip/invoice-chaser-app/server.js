require("dotenv").config();
const fs = require("fs");
const path = require("path");
const express = require("express");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const cron = require("node-cron");
const Stripe = require("stripe");

const {
  PORT = 3000, APP_URL = "http://localhost:3000", JWT_SECRET,
  DATA_DIR = "./data", STRIPE_SECRET_KEY, STRIPE_PRICE_ID, STRIPE_WEBHOOK_SECRET,
} = process.env;
if (!JWT_SECRET) { console.error("Set JWT_SECRET"); process.exit(1); }
const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;
const FREE_LIMIT = 3;
const MARKS = [-3, 1, 7, 14, 21]; // days relative to due date when a reminder goes out

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "app.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL,
  name TEXT DEFAULT '', pay_info TEXT DEFAULT '', plan TEXT DEFAULT 'free',
  stripe_customer TEXT, auto_send INTEGER DEFAULT 1, inv_seq INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS invoices(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, num TEXT NOT NULL,
  client TEXT NOT NULL, email TEXT DEFAULT '', descr TEXT NOT NULL,
  amount_cents INTEGER NOT NULL, due TEXT NOT NULL, paid_on TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sent(invoice_id INTEGER, mark INTEGER, at TEXT DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(invoice_id, mark));
`);

const app = express();
app.set("trust proxy", 1);

/* ---------- Stripe webhook (needs the raw body, so it goes before express.json) ---------- */
app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET);
  } catch (e) { return res.status(400).send("Bad signature"); }
  const o = event.data.object;
  if (event.type === "checkout.session.completed" && o.client_reference_id) {
    db.prepare("UPDATE users SET plan='pro', stripe_customer=? WHERE id=?").run(o.customer, Number(o.client_reference_id));
  } else if (event.type === "customer.subscription.updated") {
    const active = ["active", "trialing"].includes(o.status);
    db.prepare("UPDATE users SET plan=? WHERE stripe_customer=?").run(active ? "pro" : "free", o.customer);
  } else if (event.type === "customer.subscription.deleted") {
    db.prepare("UPDATE users SET plan='free' WHERE stripe_customer=?").run(o.customer);
  }
  res.json({ received: true });
});

app.use(express.json({ limit: "50kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

/* ---------- helpers ---------- */
const today = () => new Date().toISOString().slice(0, 10);
const dayDiff = (a, b) => Math.round((Date.parse(b) - Date.parse(a)) / 864e5);
const money = (c) => (c / 100).toLocaleString("en-US", { style: "currency", currency: "USD" });
const fmtDate = (s) => new Date(s + "T00:00:00Z").toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });
const clean = (s, n) => String(s || "").trim().slice(0, n);

function setSession(res, id) {
  const t = jwt.sign({ id }, JWT_SECRET, { expiresIn: "30d" });
  res.cookie("t", t, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 30 * 864e5 });
}
function auth(req, res, next) {
  try {
    const { id } = jwt.verify(req.cookies.t, JWT_SECRET);
    const u = db.prepare("SELECT * FROM users WHERE id=?").get(id);
    if (!u) throw new Error();
    req.user = u; next();
  } catch (e) { res.status(401).json({ error: "Please log in" }); }
}
const publicUser = (u) => ({ email: u.email, name: u.name, pay_info: u.pay_info, plan: u.plan, auto_send: !!u.auto_send, free_limit: FREE_LIMIT });

function buildMessage(user, inv) {
  const l = dayDiff(inv.due, today());
  const first = inv.client.split(" ")[0];
  const me = user.name || user.email;
  const ref = `${inv.num} for ${inv.descr} (${money(inv.amount_cents)})`;
  const pay = user.pay_info ? `\n\nYou can pay here:\n${user.pay_info}` : "";
  if (l < 0) return { subject: `Upcoming: invoice ${inv.num}`, body: `Hi ${first},\n\nA quick heads-up that invoice ${ref} is due on ${fmtDate(inv.due)}.${pay}\n\nThanks so much!\n${me}` };
  if (l < 7) return { subject: `Quick reminder: invoice ${inv.num}`, body: `Hi ${first},\n\nHope you're well! Invoice ${ref} was due on ${fmtDate(inv.due)} and I don't see a payment yet. It may have slipped through, so could you take a look?${pay}\n\nThank you,\n${me}` };
  if (l < 21) return { subject: `Overdue: invoice ${inv.num}`, body: `Hi ${first},\n\nInvoice ${ref} is now ${l} days overdue. Could you let me know when I can expect payment, or if there's an issue I can help resolve?${pay}\n\nThanks,\n${me}` };
  return { subject: `Final notice: invoice ${inv.num}`, body: `Hi ${first},\n\nThis is a final reminder that invoice ${ref} is ${l} days overdue. Please arrange payment within the next 5 days, or reply today so we can agree on a plan.${pay}\n\nRegards,\n${me}` };
}

async function sendEmail(user, inv, msg) {
  if (!process.env.RESEND_API_KEY || !process.env.FROM_EMAIL) throw new Error("Email sending isn't configured");
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: "Bearer " + process.env.RESEND_API_KEY, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: `${(user.name || "Invoice Chaser").replace(/[<>"]/g, "")} <${process.env.FROM_EMAIL}>`,
      reply_to: user.email, to: [inv.email], bcc: [user.email],
      subject: msg.subject, text: msg.body,
    }),
  });
  if (!r.ok) throw new Error("Email failed: " + (await r.text()));
}

/* ---------- auth ---------- */
const attempts = new Map(); // tiny in-memory brute-force guard
function tooMany(key) {
  const now = Date.now(), a = (attempts.get(key) || []).filter((t) => now - t < 15 * 60e3);
  a.push(now); attempts.set(key, a); return a.length > 10;
}
app.post("/api/signup", (req, res) => {
  const email = clean(req.body.email, 120).toLowerCase(), pw = String(req.body.password || "");
  if (tooMany(req.ip)) return res.status(429).json({ error: "Too many attempts. Try again later." });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: "Enter a valid email" });
  if (pw.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });
  if (db.prepare("SELECT 1 FROM users WHERE email=?").get(email)) return res.status(409).json({ error: "That email already has an account" });
  const info = db.prepare("INSERT INTO users(email,pass_hash,name) VALUES(?,?,?)").run(email, bcrypt.hashSync(pw, 10), clean(req.body.name, 60));
  setSession(res, info.lastInsertRowid);
  res.json(publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid)));
});
app.post("/api/login", (req, res) => {
  if (tooMany(req.ip)) return res.status(429).json({ error: "Too many attempts. Try again later." });
  const u = db.prepare("SELECT * FROM users WHERE email=?").get(clean(req.body.email, 120).toLowerCase());
  if (!u || !bcrypt.compareSync(String(req.body.password || ""), u.pass_hash)) return res.status(401).json({ error: "Wrong email or password" });
  setSession(res, u.id); res.json(publicUser(u));
});
app.post("/api/logout", (req, res) => { res.clearCookie("t"); res.json({ ok: true }); });
app.get("/api/me", auth, (req, res) => res.json(publicUser(req.user)));
app.post("/api/settings", auth, (req, res) => {
  db.prepare("UPDATE users SET name=?, pay_info=?, auto_send=? WHERE id=?")
    .run(clean(req.body.name, 60), clean(req.body.pay_info, 300), req.body.auto_send ? 1 : 0, req.user.id);
  res.json(publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id)));
});

/* ---------- invoices ---------- */
const own = (req) => db.prepare("SELECT * FROM invoices WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
app.get("/api/invoices", auth, (req, res) =>
  res.json(db.prepare("SELECT id,num,client,email,descr,amount_cents,due,paid_on FROM invoices WHERE user_id=? ORDER BY due").all(req.user.id)));
app.post("/api/invoices", auth, (req, res) => {
  const b = req.body, cents = Math.round(Number(b.amount) * 100);
  if (!clean(b.client, 60) || !clean(b.descr, 80) || !(cents > 0) || !/^\d{4}-\d{2}-\d{2}$/.test(b.due || "")) return res.status(400).json({ error: "Fill in client, description, amount and due date" });
  if (req.user.plan !== "pro") {
    const n = db.prepare("SELECT COUNT(*) c FROM invoices WHERE user_id=?").get(req.user.id).c;
    if (n >= FREE_LIMIT) return res.status(402).json({ error: `The free plan includes ${FREE_LIMIT} invoices. Upgrade for unlimited invoices and automatic follow-ups.`, upgrade: true });
  }
  const seq = req.user.inv_seq + 1;
  db.prepare("UPDATE users SET inv_seq=? WHERE id=?").run(seq, req.user.id);
  const info = db.prepare("INSERT INTO invoices(user_id,num,client,email,descr,amount_cents,due) VALUES(?,?,?,?,?,?,?)")
    .run(req.user.id, "INV-" + String(seq).padStart(3, "0"), clean(b.client, 60), clean(b.email, 120), clean(b.descr, 80), cents, b.due);
  res.json({ id: info.lastInsertRowid });
});
app.post("/api/invoices/:id/paid", auth, (req, res) => {
  if (!own(req)) return res.status(404).json({ error: "Not found" });
  db.prepare("UPDATE invoices SET paid_on=? WHERE id=?").run(req.body.undo ? null : today(), Number(req.params.id));
  res.json({ ok: true });
});
app.delete("/api/invoices/:id", auth, (req, res) => {
  if (!own(req)) return res.status(404).json({ error: "Not found" });
  db.prepare("DELETE FROM sent WHERE invoice_id=?").run(Number(req.params.id));
  db.prepare("DELETE FROM invoices WHERE id=?").run(Number(req.params.id));
  res.json({ ok: true });
});
app.get("/api/invoices/:id/message", auth, (req, res) => {
  const inv = own(req); if (!inv) return res.status(404).json({ error: "Not found" });
  res.json(buildMessage(req.user, inv));
});
app.post("/api/invoices/:id/send", auth, async (req, res) => {
  const inv = own(req); if (!inv) return res.status(404).json({ error: "Not found" });
  if (req.user.plan !== "pro") return res.status(402).json({ error: "Sending emails is part of the paid plan.", upgrade: true });
  if (!inv.email) return res.status(400).json({ error: "Add a client email to this invoice first" });
  const msg = buildMessage(req.user, inv);
  if (req.body.body) msg.body = clean(req.body.body, 3000);
  try { await sendEmail(req.user, inv, msg); res.json({ ok: true }); }
  catch (e) { console.error(e.message); res.status(502).json({ error: "Couldn't send the email. Check your email settings." }); }
});

/* ---------- billing ---------- */
app.post("/api/billing/checkout", auth, async (req, res) => {
  if (!stripe || !STRIPE_PRICE_ID) return res.status(500).json({ error: "Billing isn't configured" });
  const s = await stripe.checkout.sessions.create({
    mode: "subscription", line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
    client_reference_id: String(req.user.id),
    ...(req.user.stripe_customer ? { customer: req.user.stripe_customer } : { customer_email: req.user.email }),
    success_url: APP_URL + "/?upgraded=1", cancel_url: APP_URL + "/",
  });
  res.json({ url: s.url });
});
app.post("/api/billing/portal", auth, async (req, res) => {
  if (!stripe || !req.user.stripe_customer) return res.status(400).json({ error: "No subscription found" });
  const s = await stripe.billingPortal.sessions.create({ customer: req.user.stripe_customer, return_url: APP_URL });
  res.json({ url: s.url });
});

/* ---------- daily auto-chaser ---------- */
async function runChaser() {
  const rows = db.prepare(`
    SELECT i.*, u.email AS u_email, u.name AS u_name, u.pay_info AS u_pay
    FROM invoices i JOIN users u ON u.id = i.user_id
    WHERE i.paid_on IS NULL AND i.email != '' AND u.plan = 'pro' AND u.auto_send = 1`).all();
  for (const r of rows) {
    const l = dayDiff(r.due, today());
    const mark = MARKS.filter((m) => m <= l).pop();
    if (mark === undefined) continue;
    if (db.prepare("SELECT 1 FROM sent WHERE invoice_id=? AND mark=?").get(r.id, mark)) continue;
    const user = { email: r.u_email, name: r.u_name, pay_info: r.u_pay };
    try {
      await sendEmail(user, r, buildMessage(user, r));
      db.prepare("INSERT INTO sent(invoice_id, mark) VALUES(?,?)").run(r.id, mark);
      console.log(`Sent ${r.num} (mark ${mark}) to ${r.email}`);
    } catch (e) { console.error(`Failed ${r.num}:`, e.message); }
  }
}
cron.schedule("0 9 * * *", runChaser);

app.listen(PORT, () => console.log("Invoice Chaser running on port " + PORT));
